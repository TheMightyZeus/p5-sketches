function Bullet(image, x, y, rotation) {
	this.position = createVector(x || 100, y || 100);
	this.rotation = rotation || 0;
	this.speed = bulletSpeed;
	this.image = image;
	this.velocity = createVector(sin(radians(this.rotation)) * this.speed, -cos(radians(this.rotation)) * this.speed);
	this.radius = 10;
	this.update = function () {
		this.position.add(this.velocity);
	};
	this.draw = function () {
		renderImage(this.image, this.position.x, this.position.y, 20, 31, 10, 17, this.rotation);
	};
	this.collide = function (walls) {
		if (this.position.x < -10000 || this.position.x > 10000 || this.position.y < -10000 || this.position.y > 10000) {
			return true;
		}
		for (var i = 0; i < walls.length; i++) {
			var wall = walls[i];
			var nearestX = Math.max(wall.x, Math.min(this.position.x, wall.x + wall.width));
			var nearestY = Math.max(wall.y, Math.min(this.position.y, wall.y + wall.height));
			var point = createVector(this.position.x - nearestX, this.position.y - nearestY);
			var depth = this.radius - point.mag();
			if (depth > 0) {
				return true;
			}
		}
		return false;
	};
}
