// These are the configurable settings
var forwardSpeed = 4;
var forwardSpeedMin = 1;
var forwardSpeedMax = 10;
var forwardSpeedStep = 0.1;

var backwardSpeed = 2;
var backwardSpeedMin = 1;
var backwardSpeedMax = 10;
var backwardSpeedStep = 0.1;

var rotateSpeed = 3;
var rotateSpeedMin = 1;
var rotateSpeedMax = 8;
var rotateSpeedStep = 0.1;

var acceleration = 2;
var accelerationMin = 1;
var accelerationMax = 5;
var accelerationStep = 0.1;

var bulletSpeed = 8;
var bulletSpeedMin = 2;
var bulletSpeedMax = 25;

var zoom = 1;
var zoomMin = 0.1;
var zoomMax = 2;
var zoomStep = 0.1;

// These hold global information but are not configurable
var colors = ["Blue", "Green", "Red", "Beige"];
var tankSprites = []; // 83 x 78
var bulletSprites = []; // 20 x 34
var barrelSprites = []; // 24 x 58
var myTank;
var myBullets = [];
var mouseMode = true;
var walls = [];

function preInit(includer) {
	includer.require('p5.play');
	includer.require('p5.gui');
}

function preload() {
	for (var i = 0; i < colors.length; i++) {
		tankSprites[i] = loadImage("assets/tank" + colors[i] + ".png");
		bulletSprites[i] = loadImage("assets/bullet" + colors[i] + ".png");
		barrelSprites[i] = loadImage("assets/barrel" + colors[i] + ".png");
	}
}

function setup() {
	createCanvas(800, 600);
	myTank = new Tank(floor(random(4)));
	walls.push(new Wall(0, 0, 1500, 10)); //walls.push(new Wall(0, 0, 10, 600));
	walls.push(new Wall(0, 0, 10, 1500)); //walls.push(new Wall(0, 0, 10, 600));
	walls.push(new Wall(0, 1490, 1500, 10)); //walls.push(new Wall(0, 0, 10, 600));
	walls.push(new Wall(1490, 0, 10, 1500)); //walls.push(new Wall(0, 0, 10, 600));

	var gui = createGui('Settings');
	gui.addGlobals('forwardSpeed', 'backwardSpeed', 'rotateSpeed', 'acceleration', 'bulletSpeed', 'zoom');
}

function draw() {
	camera.zoom = zoom;
	background(0);
	if (mouseMode) {
		// TODO: Next Week
		myTank.aimAt(mouseX + (camera.position.x - width / 2) / zoom, mouseY + (camera.position.y - height / 2) / zoom);
	}
	if (keyDown("w")) {
		myTank.drive(timeLerp(myTank.speed, forwardSpeed, 1 / acceleration));
	} else if (keyDown("s")) {
		myTank.drive(timeLerp(myTank.speed, -backwardSpeed, 1 / acceleration));
	} else {
		myTank.drive(myTank.speed * 0.9);
	}
	if (keyDown("a")) {
		myTank.rotate(-rotateSpeed);
	} else if (keyDown("d")) {
		myTank.rotate(rotateSpeed);
	}
	if (mouseWentDown(LEFT)) {
		mouseMode = true;
		myBullets.push(myTank.createBullet());
	}
	myTank.update();
	myTank.collide(walls);
	myTank.drawBody();
	for (var i = myBullets.length - 1; i >= 0; i--) {
		myBullets[i].update();
		myBullets[i].draw();
		if (myBullets[i].collide(walls)) {
			myBullets.splice(i, 1);
		}
	}
	myTank.drawBarrel();
	for (var i = 0; i < walls.length; i++) {
		walls[i].draw();
	}
	//camera.position.lerp(myTank.position, 0.05);
	camera.position = myTank.position.copy().add(myTank.velocity.copy().mult(20));
	//camera.position.lerp(myTank.position.copy().add(myTank.velocity.copy().mult(30)), 0.1);
	//camera.position = myTank.position;
}

function timeLerp(a, b, naiveDuration) {
	return lerp(a, b, 1 / naiveDuration / getFrameRate());
}

function renderImage(img, x, y, width, height, offsetX, offsetY, rotation) {
	push();
	translate(x, y);
	rotate(radians(rotation));
	translate(-offsetX, -offsetY);
	image(img, 0, 0, width, height);
	pop();
}

function mouseWheel(scroll) {
	if (scroll.delta > 0) {
		zoom = Math.max(zoomMin, zoom - zoomStep);
	} else {
		zoom = Math.min(zoomMax, zoom + zoomStep);
	}
	return false;
}
