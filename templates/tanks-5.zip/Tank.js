function Tank(colorIndex, x, y) {
	this.position = createVector(x || 100, y || 100);
	this.velocity = createVector(0, 0);
	this.body = tankSprites[colorIndex];
	this.barrel = barrelSprites[colorIndex];
	this.bullet = bulletSprites[colorIndex];
	this.bodyRotation = 0;
	this.barrelRotation = 0;
	this.radius = 40;

	this.aimAt = function (x, y) {
		this.barrelRotation = degrees(atan2(y - this.position.y, x - this.position.x)) + 90;
	};

	this.drive = function (speed) {
		var x = sin(radians(this.bodyRotation)) * speed;
		var y = -cos(radians(this.bodyRotation)) * speed;
		this.setVelocity(x, y);
	};

	this.rotate = function (amount) {
		this.bodyRotation += amount;
	};

	this.rotateBarrel = function (amount) {
		this.barrelRotation += amount;
	};

	this.setVelocity = function (x, y) {
		this.velocity = createVector(x, y);
	};

	this.update = function () {
		this.position.add(this.velocity);
	};

	this.drawBody = function () {
		renderImage(this.body, this.position.x, this.position.y, 83, 78, 41.5, 39, this.bodyRotation + 180);
	};

	this.drawBarrel = function () {
		renderImage(this.barrel, this.position.x, this.position.y, 24, 58, 12, 46, this.barrelRotation);
	};

	this.createBullet = function () {
		return new Bullet(this.bullet, this.position.x, this.position.y, this.barrelRotation);
	};

	this.collide = function (walls) {
		for (var i = 0; i < walls.length; i++) {
			var wall = walls[i];
			var nearestX = Math.max(wall.x, Math.min(this.position.x, wall.x + wall.width));
			var nearestY = Math.max(wall.y, Math.min(this.position.y, wall.y + wall.height));
			var point = createVector(this.position.x - nearestX, this.position.y - nearestY);
			var depth = this.radius - point.mag();
			if (depth > 0) {
				var vector = point.normalize().mult(depth);
				this.position.add(vector);
			}
		}
	};
}
