function setup() {
	createCanvas(450, 450);
}

function draw() {
	background(0);
	strokeWeight(4);
	stroke(255);
	noFill();
	translate(width / 2, height / 2);
	scale(1);
	line(0, 125, -116, -14);
	line(0, 125, 116, -14);
	arc(-62.5, -47, 125, 125, PI * 0.8, 0);
	arc(62.5, -47, 125, 125, PI, PI * 0.2);
}
