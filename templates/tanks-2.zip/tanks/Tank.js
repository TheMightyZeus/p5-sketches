function Tank(colorIndex, x, y) {
	this.position = createVector(x || 100, y || 100);
	this.velocity = createVector(0, 0);
	this.body = tankSprites[colorIndex];
	this.barrel = barrelSprites[colorIndex];
	this.bullet = bulletSprites[colorIndex];
	this.bodyRotation = 0;
	this.barrelRotation = 0;

	this.aimAt = function (x, y) {
		this.barrelRotation = degrees(atan2(y - this.position.y, x - this.position.x)) + 90;
	};

	this.drive = function (speed) {
		setVelocity(sin(degrees(bodyRotation)), cos(degrees(bodyRotation)));
	};

	this.rotate = function (amount) {
		this.bodyRotation += amount;
	};

	this.setVelocity = function (x, y) {
		this.velocity = createVector(x, y);
	};

	this.update = function () {
		this.position.add(this.velocity);
	};

	this.draw = function () {
		renderImage(this.body, this.position.x, this.position.y, 83, 78, 41.5, 39, this.bodyRotation);
		renderImage(this.barrel, this.position.x, this.position.y, 24, 58, 12, 46, this.barrelRotation);
	};
}
