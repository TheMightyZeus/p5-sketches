var colors = ["Blue", "Green", "Red", "Beige"];
var tankSprites = []; // 83 x 78
var bulletSprites = []; // 20 x 34
var barrelSprites = []; // 24 x 58

function preload() {
	for (var i = 0; i < colors.length; i++) {
		tankSprites[i] = loadImage("assets/tank" + colors[i] + ".png");
		bulletSprites[i] = loadImage("assets/bullet" + colors[i] + ".png");
		barrelSprites[i] = loadImage("assets/barrel" + colors[i] + ".png");
	}
}

function setup() {
	createCanvas(400, 400);
}

function draw() {
	background(0);
}

function renderImage(image, x, y, width, height, offsetX, offsetY, rotation) {
	push();
	translate(-offsetX, -offsetY);
	rotate(radians(rotation));
	translate(x, y);
	image(image, 0, 0, width, height);
	pop();
}
