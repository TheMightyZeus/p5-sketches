function Tank(colorIndex, x, y) {
	this.position = createVector(x || 100, y || 100);
	this.body = tankSprites[colorIndex];
	this.barrel = barrelSprites[colorIndex];
	this.bullet = bulletSprites[colorIndex];
	this.bodyRotation = 0;
	this.barrelRotation = 0;

	this.draw = function () {
		//
	}
}
