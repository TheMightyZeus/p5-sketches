var webAudio = (function () {
	var myAudioContext;
	if ('webkitAudioContext' in window) {
		myAudioContext = new webkitAudioContext();
	} else if ('AudioContext' in window) {
		myAudioContext = new AudioContext();
	} else {
		// Fallback? Return a dummy manager?
	}

	var manager = {
		"loadSound": function (url) {
			var sound = {
				"url": url,
				"loaded": false,
				"data": null,
				"play": function (delay) {
					manager.playSound(sound, delay);
				}
			};
			var request = new XMLHttpRequest();
			request.open('GET', url, true);
			request.responseType = 'arraybuffer';
			request.addEventListener('load', function (ev) {
				var source = myAudioContext.createBufferSource();
				source.buffer = myAudioContext.createBuffer(request.response, false);
				source.connect(myAudioContext.destination);
				sound.data = source;
				sound.loaded = true;
				sound.duration = source.buffer.duration;
			}, false);
			request.send();
			return sound;
		},
		"playSound": function (sound, delay) {
			if (sound.loaded) {
				sound.data.noteOn(myAudioContext.currentTime + (delay || 0));
			}
		}
	};
	return manager;
})();
