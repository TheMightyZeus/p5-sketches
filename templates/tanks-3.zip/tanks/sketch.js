var colors = ["Blue", "Green", "Red", "Beige"];
var tankSprites = []; // 83 x 78
var bulletSprites = []; // 20 x 34
var barrelSprites = []; // 24 x 58
var myTank;
var myBullets = [];

function preload() {
	for (var i = 0; i < colors.length; i++) {
		tankSprites[i] = loadImage("assets/tank" + colors[i] + ".png");
		bulletSprites[i] = loadImage("assets/bullet" + colors[i] + ".png");
		barrelSprites[i] = loadImage("assets/barrel" + colors[i] + ".png");
	}
}

function setup() {
	createCanvas(800, 600);
	myTank = new Tank(floor(random(4)));
}

function draw() {
	background(0);
	myTank.aimAt(mouseX, mouseY);
	if (keyDown("w")) {
		myTank.drive(4);
	} else if (keyDown("s")) {
		myTank.drive(-2);
	} else {
		myTank.drive(0);
	}
	if (keyDown("a")) {
		myTank.rotate(-3);
	} else if (keyDown("d")) {
		myTank.rotate(3);
	}
	myTank.update();
	myTank.drawBody();
	for (var i = 0; i < myBullets.length; i++) {
		myBullets[i].update();
		myBullets[i].draw();
	}
	myTank.drawBarrel();
}

function renderImage(img, x, y, width, height, offsetX, offsetY, rotation) {
	push();
	translate(x, y);
	rotate(radians(rotation));
	translate(-offsetX, -offsetY);
	image(img, 0, 0, width, height);
	pop();
}
