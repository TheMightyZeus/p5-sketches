function Bullet(image, x, y, rotation) {
	this.position = createVector(x || 100, y || 100);
	this.rotation = rotation || 0;
	this.speed = 8;
	this.image = image;
	this.update = function () {
		var x = sin(radians(this.rotation)) * this.speed;
		var y = -cos(radians(this.rotation)) * this.speed;
		var vel = createVector(x, y);
		this.position.add(vel);
	};
	this.draw = function () {
		renderImage(this.image, this.position.x, this.position.y, 20, 31, 10, 17, this.rotation);
	};
}
